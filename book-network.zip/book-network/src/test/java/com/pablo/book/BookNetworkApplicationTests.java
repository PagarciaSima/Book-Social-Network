package com.pablo.book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookNetworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
